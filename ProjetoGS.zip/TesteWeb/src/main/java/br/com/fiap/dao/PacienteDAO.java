package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.conexoes.ConexaoFactory;
import br.com.fiap.model.Paciente;

public class PacienteDAO {

	public Connection minhaconexao;

	public PacienteDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaconexao = new ConexaoFactory().conexao();
	}

	// MÉTODO INSERT

	public String inserir(Paciente paciente) throws SQLException {
		PreparedStatement stmt = minhaconexao.prepareStatement("Insert into T_FIAP_PACIENTE values (?,?,?,?,?) ");
		stmt.setString(1, paciente.getNome());
		stmt.setInt(2, paciente.getIdade());
		stmt.setString(3, paciente.getRg());
		stmt.setString(4, paciente.getCpf());
		stmt.setDouble(5, paciente.getPeso());
		stmt.execute();
		stmt.close();

		return "Cadastrado com sucesso!!!";
	}

	// MÉTODO DELETE

	public String deletar(Paciente paciente) throws SQLException {
		PreparedStatement stmt = minhaconexao.prepareStatement("Delete from T_FIAP_PACIENTE where NOME_PACIENTE = ? ");
		stmt.setString(1, paciente.getNome());
		stmt.execute();
		stmt.close();

		return "Deletado com sucesso!!!";
	}

	// MÉTODO UPDATE

	public String alterar(Paciente paciente) throws SQLException {
		PreparedStatement stmt = minhaconexao
				.prepareStatement("Update T_FIAP_PACIENTE set IDADE_PACIENTE = ?, RG_PACIENTE = ?,"
						+ "CPF_PACIENTE = ?, PESO_PACIENTE = ? where NOME_PACIENTE = ? ");
		stmt.setInt(1, paciente.getIdade());
		stmt.setString(2, paciente.getRg());
		stmt.setString(3, paciente.getCpf());
		stmt.setDouble(4, paciente.getPeso());
		stmt.setString(5, paciente.getNome());
		stmt.executeUpdate();
		stmt.close();

		return "Alterado com sucesso!!!";
	}

	// MÉTODO SELECT
	public List<Paciente> selecionar() throws SQLException {
	    List<Paciente> listaPaciente = new ArrayList<Paciente>();
	    PreparedStatement stmt = minhaconexao.prepareStatement("SELECT * FROM T_FIAP_PACIENTE");
	    ResultSet rs = stmt.executeQuery();

	    while (rs.next()) {
	        Paciente paciente = new Paciente();
	        paciente.setNome(rs.getString(1));
	        paciente.setIdade(rs.getInt(2));
	        paciente.setRg(rs.getString(3));
	        paciente.setCpf(rs.getString(4));
	        paciente.setPeso(rs.getDouble(5));
	        
	        listaPaciente.add(paciente);
	    }

	    return listaPaciente;
	}
}
