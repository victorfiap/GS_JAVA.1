package br.com.fiap.main;

import java.io.IOException;

import javax.swing.JOptionPane;

import org.apache.http.client.ClientProtocolException;

import br.com.fiap.model.EnderecoPaciente;
import br.com.fiap.service.ViaCepService;

public class TesteViaCepService {

	public static void main(String[] args) throws ClientProtocolException, IOException {

		// INSTANCIAR OBJETOS

		ViaCepService viaCep = new ViaCepService();

		String cep = JOptionPane.showInputDialog("Informe o cep a ser pesquisado");

		EnderecoPaciente endereco = viaCep.getEndereco(cep);

		System.out.println(endereco);

	}

}
