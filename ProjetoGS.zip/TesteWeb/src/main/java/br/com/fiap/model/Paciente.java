package br.com.fiap.model;

public class Paciente {
	
	// VISIBILIDADE, TIPO DE DADO E O NOME DA VARIÁVEL
	
	private String nome;
	private int idade;
	private String rg;
	private String cpf;
	private double peso;
	private EnderecoPaciente enderecopaciente;
	
	// MÉTODO CONTRUTORES VAZIO E CHEIO
	
	public Paciente() {
		super();
	}

	public Paciente(String nome, int idade, String rg, String cpf, double peso, EnderecoPaciente enderecopaciente) {
		super();
		this.nome = nome;
		this.idade = idade;
		this.rg = rg;
		this.cpf = cpf;
		this.peso = peso;
		this.enderecopaciente = enderecopaciente;
	}

	// SETTERS E GETTERS
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public EnderecoPaciente getEnderecopaciente() {
		return enderecopaciente;
	}

	public void setEnderecopaciente(EnderecoPaciente enderecopaciente) {
		this.enderecopaciente = enderecopaciente;
	}
}
