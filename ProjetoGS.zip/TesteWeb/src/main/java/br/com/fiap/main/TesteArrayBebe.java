package br.com.fiap.main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.model.Bebe;

public class TesteArrayBebe {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double decimal(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {

		// INSTANCIAR OBJETOS

		List<Bebe> listaBebe = new ArrayList<Bebe>();
		Bebe objBebe = new Bebe();

		do {
			objBebe = new Bebe();
			objBebe.setNome(texto("Nome do bebe"));
			objBebe.setIdade(inteiro("Digite a idade do bebe"));
			objBebe.setPeso(decimal("Informe o peso do bebe"));
			objBebe.setNomeResponsavel(texto("Digite o nome do responsavel"));
			objBebe.setTipoSanguineoBebe(texto("Qual o tipo sanguíneo do bebe"));
			objBebe.setCpfResponsavel(texto("Digite o cpf do responsavel"));

			listaBebe.add(objBebe);
		} while (JOptionPane.showConfirmDialog(null, "Adicionar mais informações do bebe?", "INFORMAÇÕES DO BEBE",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);

		// SAÍDA
		for (Bebe b : listaBebe) {
			System.out.println("INFORMAÇÕES DO BEBE" + "\n\nNome do bebe: " + objBebe.getNome() + "\nIdade do bebe: " + objBebe.getIdade()
					+ "\nPeso do bebe: " + objBebe.getPeso() + "\nNome do responsável: " + objBebe.getNomeResponsavel()
					+ "\nTipo sanguineo do bebe: " + objBebe.getTipoSanguineoBebe() + "\nCPF do responsável: "
					+ objBebe.getCpfResponsavel());
		}
	}

}
