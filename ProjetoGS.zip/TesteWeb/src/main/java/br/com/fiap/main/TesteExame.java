package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.model.Exame;

public class TesteExame {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static Double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {
		
		Exame objExame = new Exame();
		
		objExame.setTipoExame(texto("Tipo do exame?"));
		objExame.setData(texto("Data do exame"));
		objExame.setHora(texto("Hora do exame"));
		objExame.setSintomas(texto("Sintomas apresentado?"));
		objExame.setLocal(texto("Local que o exame será realizado?"));
		
		System.out.println("Tipo do exame: " + objExame.getTipoExame() +
							"\nData do exame: " + objExame.getData() +
							"\nHora do exame: " + objExame.getHora() + 
							"\nSintomas apresentados: " + objExame.getSintomas() +
							"\nLocal: " + objExame.getLocal());
	}

}
