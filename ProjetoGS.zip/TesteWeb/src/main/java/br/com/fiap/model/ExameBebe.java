package br.com.fiap.model;

public class ExameBebe {

	// VISIBILIDADE, TIPO DE DADOS E ON OME DA VARIÁVEL

	private String tipoCosulta;
	private String dataConsulta;
	private String localConsulta;

	// MÉTODOS CONTRUTORES VAZIO E CHEIO

	public ExameBebe() {
		super();
	}

	public ExameBebe(String tipoCosulta, String dataConsulta, String localConsulta) {
		super();
		this.tipoCosulta = tipoCosulta;
		this.dataConsulta = dataConsulta;
		this.localConsulta = localConsulta;
	}

	// SETTERS E GETTERS

	public String getTipoCosulta() {
		return tipoCosulta;
	}

	public void setTipoCosulta(String tipoCosulta) {
		this.tipoCosulta = tipoCosulta;
	}

	public String getDataConsulta() {
		return dataConsulta;
	}

	public void setDataConsulta(String dataConsulta) {
		this.dataConsulta = dataConsulta;
	}

	public String getLocalConsulta() {
		return localConsulta;
	}

	public void setLocalConsulta(String localConsulta) {
		this.localConsulta = localConsulta;
	}

}
