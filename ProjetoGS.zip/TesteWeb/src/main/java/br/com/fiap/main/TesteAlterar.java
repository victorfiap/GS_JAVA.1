package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.dao.PacienteDAO;
import br.com.fiap.model.Paciente;

public class TesteAlterar {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double decimal(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		PacienteDAO dao = new PacienteDAO();

		Paciente objPaciente = new Paciente();

		objPaciente.setNome(texto("Nome do paciente"));
		objPaciente.setIdade(inteiro("idade do paciente"));
		objPaciente.setRg(texto("Informe o RG do paciente"));
		objPaciente.setCpf(texto("Digite o CPF do paciente"));
		objPaciente.setPeso(decimal("Informe o peso do paciente"));

		System.out.println(dao.alterar(objPaciente));

	}

}
