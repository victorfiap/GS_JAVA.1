package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.model.Consulta;

public class TesteConsulta {
	
	// MÉTODO STATIC

			static String texto(String j) {
				return JOptionPane.showInputDialog(j);
			}

			static int inteiro(String j) {
				return Integer.parseInt(JOptionPane.showInputDialog(j));
			}

			static Double real(String j) {
				return Double.parseDouble(JOptionPane.showInputDialog(j));
			}

	public static void main(String[] args) {
		
		// INSTANCIAR OBJETOS 

		Consulta objConsulta = new Consulta();

		objConsulta.setTipoConsulta(texto("Digite o tipo de consulta"));
		objConsulta.setData(texto("Informe a data da consulta"));
		objConsulta.setHora(texto("Informe a hora da consulta"));
		objConsulta.setSintomas(texto("Digite os sintomas do paciente"));
		objConsulta.setLocal(texto("Informe o local da consulta"));
		
		System.out.println("Tipo da consulta: " + objConsulta.getTipoConsulta()+ 
										"\nData da consulta: " + objConsulta.getData() + 
										"\nHora marcada da consulta: " + objConsulta.getHora() +
										"\nSintomas apresentado: " + objConsulta.getSintomas() + 
										"\nLocal marcado: " + objConsulta.getLocal());

		

	}

}
