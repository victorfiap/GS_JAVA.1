package br.com.fiap.model;

public class ConsultaBebe {

	// VISIBILIDADE,TIPO DE DADOS E O NOME DA VARIÁVEL

	private String SintomasBebe;
	private String dataConsulta;
	private String horaConsulta;

	public ConsultaBebe() {
		super();
	}

	public ConsultaBebe(String sintomasBebe, String dataConsulta, String horaConsulta) {
		super();
		SintomasBebe = sintomasBebe;
		this.dataConsulta = dataConsulta;
		this.horaConsulta = horaConsulta;
	}

	// SETTERS E GETTERS
	
	public String getSintomasBebe() {
		return SintomasBebe;
	}

	public void setSintomasBebe(String sintomasBebe) {
		SintomasBebe = sintomasBebe;
	}

	public String getDataConsulta() {
		return dataConsulta;
	}

	public void setDataConsulta(String dataConsulta) {
		this.dataConsulta = dataConsulta;
	}

	public String getHoraConsulta() {
		return horaConsulta;
	}

	public void setHoraConsulta(String horaConsulta) {
		this.horaConsulta = horaConsulta;
	}

}
