package br.com.fiap.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.dao.PacienteDAO;
import br.com.fiap.model.Paciente;  

public class PacienteBO {  
	
    private PacienteDAO pacienteDao; 

    // Selecionar
    public ArrayList<Paciente> selecionarBo() throws SQLException, ClassNotFoundException {
        pacienteDao = new PacienteDAO();  
        return (ArrayList<Paciente>) pacienteDao.selecionar();
    }

    public void inserirBo(Paciente paciente) throws ClassNotFoundException, SQLException {
        PacienteDAO pacienteDAO = new PacienteDAO();
        pacienteDAO.inserir(paciente);
    }

    public void atualizarBo(Paciente paciente) throws ClassNotFoundException, SQLException {
        PacienteDAO pacienteDAO = new PacienteDAO();
        pacienteDAO.alterar(paciente);
    }

    public void deletarBo(Paciente paciente) throws ClassNotFoundException, SQLException {
        PacienteDAO pacienteDAO = new PacienteDAO();
        pacienteDAO.deletar(paciente);
    }

}