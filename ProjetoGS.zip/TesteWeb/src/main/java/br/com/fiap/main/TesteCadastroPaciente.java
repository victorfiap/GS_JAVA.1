package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.model.Cadastro;

public class TesteCadastroPaciente {
	
	// MÉTODO STATIC

		static String texto(String j) {
			return JOptionPane.showInputDialog(j);
		}

		static int inteiro(String j) {
			return Integer.parseInt(JOptionPane.showInputDialog(j));
		}

		static Double real(String j) {
			return Double.parseDouble(JOptionPane.showInputDialog(j));
		}

	public static void main(String[] args) {
		
		// INSTANCIAR OBJETOS 
		
		Cadastro objCadastro = new Cadastro();
		
		objCadastro.setNome(texto("Digite o nome do paciente"));
	    objCadastro.setIdade(inteiro("Informe a idade do paciente"));
	    objCadastro.setEmail(texto("Digite seu email"));
	    objCadastro.setTelefone(texto("Digite seu telefone para contato"));
	    objCadastro.setEndereco(texto("Informe seu endereco"));
	    objCadastro.setCpf(texto("Digite o CPF do paciente")); 
	    objCadastro.setDataNascimento(texto("Data de nascimento"));
	    
	    System.out.println("Nome cadastrado: " + objCadastro.getNome() + 
	    						"\nIdade: " + objCadastro.getIdade() + 
	    						"\nE-mail cadastrado: " + objCadastro.getEmail() + 
	    						"\nTelefone: " + objCadastro.getTelefone() + 
	    						"\nEndereco cadastrado: " + objCadastro.getEndereco() + 
	    						"\nCPF: " + objCadastro.getCpf() + 
	    						"\nData de nascimento: " + objCadastro.getDataNascimento());
	    
	    System.out.println("\nStatus de informação de email:" + objCadastro.validacaoEmailLogin());
	    

	}

}
