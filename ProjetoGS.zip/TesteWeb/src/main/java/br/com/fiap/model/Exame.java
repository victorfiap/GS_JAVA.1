package br.com.fiap.model;

public class Exame {

	// VISIBILIDADE, TIPO DE DADOS E O NOME DA VARIÁVEL

	private String tipoExame;
	private String data;
	private String hora;
	private String sintomas;
	private String local;

	// MÉTODOS CONSTRUTORES VAZIO E CHEIO

	public Exame() {
		super();
	}

	public Exame(String tipoExame, String data, String hora, String sintomas, String local) {
		super();
		this.tipoExame = tipoExame;
		this.data = data;
		this.hora = hora;
		this.sintomas = sintomas;
		this.local = local;
	}

	// SETTERS E GETTERS

	public String getTipoExame() {
		return tipoExame;
	}

	public void setTipoExame(String tipoConsulta) {
		this.tipoExame = tipoConsulta;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getSintomas() {
		return sintomas;
	}

	public void setSintomas(String sintomas) {
		this.sintomas = sintomas;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

}
