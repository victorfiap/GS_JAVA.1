package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.dao.PacienteDAO;
import br.com.fiap.model.Paciente;

public class TesteDeletar {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static double decimal(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		PacienteDAO dao = new PacienteDAO();

		Paciente objPaciente = new Paciente();

		objPaciente.setNome(texto("Infrome o nome do paciente a ser deletado"));
		
		System.out.println(dao.deletar(objPaciente));

	}

}
