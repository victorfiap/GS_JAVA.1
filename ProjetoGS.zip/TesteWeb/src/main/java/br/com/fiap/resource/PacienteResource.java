package br.com.fiap.resource;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.bo.PacienteBO;  
import br.com.fiap.model.Paciente;

@Path("/paciente") 
public class PacienteResource {  

    private PacienteBO pacienteBO = new PacienteBO(); 

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Paciente> buscar() throws SQLException, ClassNotFoundException {
        return (ArrayList<Paciente>) pacienteBO.selecionarBo();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response cadastroRs(Paciente paciente, @Context UriInfo uriInfo) throws ClassNotFoundException, SQLException {
        pacienteBO.inserirBo(paciente);
        UriBuilder builder = uriInfo.getAbsolutePathBuilder();
        builder.path(Integer.toString(paciente.getIdade())); 
        return Response.created(builder.build()).build();
    }

    @PUT
    @Path("/{nome}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response atualizaRs(Paciente paciente, @PathParam("nome") String nome) throws SQLException, ClassNotFoundException {
        pacienteBO.atualizarBo(paciente);
        return Response.ok().build();
    }

    @DELETE
    @Path("/{nome}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deleteRs(Paciente paciente,@PathParam("nome") String nome) throws ClassNotFoundException, SQLException {
        PacienteBO pacienteBO = new PacienteBO(); 
        pacienteBO.deletarBo(paciente);
        return Response.ok().build();
    }

}