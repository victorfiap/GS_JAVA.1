package br.com.fiap.model;

public class Parente {

	// VISIBILIDADE, TIPO DE DADO E O NOME DA VARIÁVEL

	private String nome;
	private int idade;
	private String Cpf;
	private String rg;
	private EnderecoParente enderecoParente;

	// MÉTODOS CONSTRUTORES VAZIO E CHEIO

	public Parente() {
		super();
	}

	public Parente(String nome, int idade, String cpf, String rg, EnderecoParente enderecoParente) {
		super();
		this.nome = nome;
		this.idade = idade;
		Cpf = cpf;
		this.rg = rg;
		this.enderecoParente = enderecoParente;
	}

	// SETTERS E GETTERS

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getCpf() {
		return Cpf;
	}

	public void setCpf(String cpf) {
		Cpf = cpf;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public EnderecoParente getEnderecoParente() {
		return enderecoParente;
	}

	public void setEnderecoParente(EnderecoParente enderecoParente) {
		this.enderecoParente = enderecoParente;
	}

}
