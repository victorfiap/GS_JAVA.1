package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.model.ConsultaBebe;

public class TesteConsultaBebe {
	
	// MÉTODO STATIC

			static String texto(String j) {
				return JOptionPane.showInputDialog(j);
			}

			static int inteiro(String j) {
				return Integer.parseInt(JOptionPane.showInputDialog(j));
			}

			static Double real(String j) {
				return Double.parseDouble(JOptionPane.showInputDialog(j));
			}

	public static void main(String[] args) {

		ConsultaBebe objConsultaBebe = new ConsultaBebe();
		
		objConsultaBebe.setSintomasBebe(texto("Sintomas apresentado no bebe?"));
		objConsultaBebe.setDataConsulta(texto("Data de consulta"));
		objConsultaBebe.setHoraConsulta(texto("Hora agendada da consulta"));
		
		System.out.println("Informações da consulta do bebe" + 
							"\n\nSintomas apresentados: " + objConsultaBebe.getSintomasBebe() + 
							"\nData da consulta: " + objConsultaBebe.getDataConsulta() + 
							"\nHora da consulta: " + objConsultaBebe.getHoraConsulta());

	}

}
