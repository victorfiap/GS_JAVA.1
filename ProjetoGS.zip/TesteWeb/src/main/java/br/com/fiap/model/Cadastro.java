package br.com.fiap.model;

public class Cadastro {

	// VISIBILIDADE, TIPO DE DADOS E O NOME DA VARIÁVEL

	private String nome;
	private int idade;
	private String email;
	private String telefone;
	private String endereco;
	private String cpf;
	private String dataNascimento;

	// MÉTODOS CONSTRUTORES VAZIO E CHEIO

	public Cadastro() {
		super();
	}

	public Cadastro(String nome, int idade, String email, String telefone, String endereco, String cpf,
			String dataNascimento) {

		this.nome = nome;
		this.idade = idade;
		this.email = email;
		this.telefone = telefone;
		this.endereco = endereco;
		this.cpf = cpf;
		this.dataNascimento = dataNascimento;
	}

	// SETTERS E GETTERS 

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getEmail() {

		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	
	public String validacaoEmailLogin() {
	    String mensagem;
	    if (email == null || email.equals("")) {
	        mensagem = "Digite seu email por favor!";
	    } else {
	        mensagem = "Email válido!";
	    }
	    return mensagem;
	}
}
