package br.com.fiap.model;

public class Bebe {

	// VISIBILIDADE, TIPO DE DADO E O NOME DA VARIÁVEL

	private String nome;
	private int idade;
	private double peso;
	private String nomeResponsavel;
	private String tipoSanguineoBebe;
	private String CpfResponsavel;

	// MÉTODOS CONSTRUTORES VAZIO E CHEIO

	public Bebe() {
		super();
	}

	public Bebe(String nome, int idade, double peso, String nomeResponsavel, String tipoSanguineoBebe,
			String cpfResponsavel) {
		super();
		this.nome = nome;
		this.idade = idade;
		this.peso = peso;
		this.nomeResponsavel = nomeResponsavel;
		this.tipoSanguineoBebe = tipoSanguineoBebe;
		this.CpfResponsavel = cpfResponsavel;
	}

	// SETTERS E GETTERS

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getNomeResponsavel() {
		return nomeResponsavel;
	}

	public void setNomeResponsavel(String nomeResponsavel) {
		this.nomeResponsavel = nomeResponsavel;
	}

	public String getTipoSanguineoBebe() {
		return tipoSanguineoBebe;
	}

	public void setTipoSanguineoBebe(String tipoSanguineoBebe) {
		this.tipoSanguineoBebe = tipoSanguineoBebe;
	}

	public String getCpfResponsavel() {
		return CpfResponsavel;
	}

	public void setCpfResponsavel(String cpfResponsavel) {
		CpfResponsavel = cpfResponsavel;
	}

}
