package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.model.ExameBebe;

public class TesteExameBebe {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static Double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {

		ExameBebe objExameBebe = new ExameBebe();

		objExameBebe.setTipoCosulta(texto("Tipo do exame?"));
		objExameBebe.setDataConsulta(texto("Data do exame"));
		objExameBebe.setLocalConsulta(texto("Qual o local do exame"));

		System.out.println("EXAME DO BEBE");
		System.out.println("Tipo do exame: " + objExameBebe.getTipoCosulta() + "\nData do exame: "
				+ objExameBebe.getDataConsulta() + "\nLocal do exame: " + objExameBebe.getLocalConsulta());

	}

}
