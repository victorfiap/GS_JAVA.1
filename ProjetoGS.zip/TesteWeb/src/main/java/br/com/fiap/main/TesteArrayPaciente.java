package br.com.fiap.main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.com.fiap.model.Paciente;

public class TesteArrayPaciente {
	
	// MÉTODO STATIC

		static String texto(String j) {
			return JOptionPane.showInputDialog(j);
		}

		static int inteiro(String j) {
			return Integer.parseInt(JOptionPane.showInputDialog(j));
		}

		static double decimal(String j) {
			return Double.parseDouble(JOptionPane.showInputDialog(j));
		}

	public static void main(String[] args) {
		
		List<Paciente> listaPaciente = new ArrayList<Paciente>();
		Paciente objPaciente = new Paciente();

		do {
		    objPaciente = new Paciente();
		    objPaciente.setNome(texto("Digite o nome do paciente"));
		    objPaciente.setIdade(inteiro("Informe a idade do paciente"));
		    objPaciente.setRg(texto("Informe o RG do paciente")); 
		    objPaciente.setCpf(texto("Digite o CPF do paciente"));  
		    objPaciente.setPeso(decimal("Informe o peso do paciente"));

		    listaPaciente.add(objPaciente);

		} while (JOptionPane.showConfirmDialog(null, "Adicionar mais informação do paciente?", "INFORMAÇÕES DO PACIENTE",
		        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == 0);

		// SAÍDA
		for(Paciente p : listaPaciente) {
			System.out.println("Nome do paciente: " + p.getNome() + "\nIdade: " + p.getIdade() + "\nRG: " + p.getRg() 
			+ "\nCPF: " + p.getCpf() + "\nPeso: " + p.getPeso());
		}
	}

}
