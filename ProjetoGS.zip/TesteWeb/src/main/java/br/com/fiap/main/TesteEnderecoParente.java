package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.model.EnderecoParente;

public class TesteEnderecoParente {

	// MÉTODO STATIC

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	static Double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) {

		// INSTANCIAR OBJETOS
		
		EnderecoParente objEnderecoParente = new EnderecoParente();
		
		objEnderecoParente.setCep(texto("Informe o cep do parente"));
		objEnderecoParente.setLogradouro(texto("Informe seu logradouro"));
		objEnderecoParente.setBairro(texto("Digite o bairro"));
		objEnderecoParente.setEstado(texto("Digite o estado do parente"));
		objEnderecoParente.setCidade(texto("Informe a cidade"));
		
		// SAÍDA
		System.out.println("INFORMAÇÕES DO PARENTE" + "\n\nCep: " + objEnderecoParente.getCep() + 
														"\nLogradouro: " + objEnderecoParente.getLogradouro() + 
														"\nBairro: " + objEnderecoParente.getBairro() + 
														"\nEstado: " + objEnderecoParente.getEstado() + 
														"\nCidade: " + objEnderecoParente.getCidade());

	}

}
