package br.com.fiap.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.dao.PacienteDAO;
import br.com.fiap.model.Paciente;

public class TesteSelecionar {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		// INSTANCIAR OBJETOS

		PacienteDAO dao = new PacienteDAO();

		List<Paciente> listaPaciente = (ArrayList<Paciente>) dao.selecionar();

		if (listaPaciente != null) {
			// FOREACH
			for (Paciente paciente : listaPaciente) {
				System.out.println(paciente.getNome() + " " + paciente.getIdade() + " " + paciente.getRg() + " "
						+ paciente.getCpf() + " " + paciente.getPeso() + " ");
			}
		}
	}

}
